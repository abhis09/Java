package com.assignment.task2;

public class Program3 {
    public static void main(String[] args) {
        int a=56;
        int b=7;
        int quotient= a/b;
        int remainder=a&b;
        System.out.println("quotient " + quotient);
        System.out.println("remainder " + remainder);

    }
}
