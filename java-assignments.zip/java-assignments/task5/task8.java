package com.assignment.task5;

import java.util.Scanner;

public class task8 {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);

    }
}
