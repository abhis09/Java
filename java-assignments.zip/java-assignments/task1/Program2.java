package com.assignment.task1;

import java.util.Scanner;

public class Program2 {
    public static void main(String[] args) {
        System.out.println("Enter your name:");
        Scanner sc=new Scanner(System.in);
        String name=sc.nextLine();
        System.out.println("My name is " + name);

    }
}
