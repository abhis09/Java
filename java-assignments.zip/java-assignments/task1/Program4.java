package com.assignment.task1;

import java.util.Scanner;

public class Program4 {
    public static void main(String[] args) {
        //program for add two numbers

        Scanner sc=new Scanner(System.in);
        System.out.println("Enter two numbers");
        int x=sc.nextInt();
        int y= sc.nextInt();
        int sum = x+y;
        System.out.println(sum);

    }
}
