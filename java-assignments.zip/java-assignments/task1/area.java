package com.assignment.task1;

import java.util.Scanner;

public class area {
    public static void main(String[] args) {
        System.out.println("find the area of circle");
        int radius,area;
        Scanner sc= new Scanner(System.in);
        radius=sc.nextInt();
        System.out.println("area of circle "+3.14*radius*radius );

    }
}
