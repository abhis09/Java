package com.assignment.task1;

public class Program1 {

    public static void main(String[] args) {
      // First Program
        String a= "Abhishek";
        System.out.println("My name is " + a);



    }
}
